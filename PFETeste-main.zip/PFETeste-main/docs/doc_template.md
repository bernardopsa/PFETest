---
id: nome_do_documento
title: Titulo do documento
---


## Introdução

<p align = "justify">
<!-- Escreva uma introdução simples e concisa, explicando do que se trata o documento e como ele será usado no projeto (qual o objetivo do documento). -->
</p>

## Metodologia 

<p align = "justify">
<!-- Descreva como o documento foi feito, como a técnica foi utilizada no projeto. -->
</p>

## Desenvolvimento (Renomeie este tópico)   

<!-- Mude o título do tópico de desenvolvimento para outros individuais de cada artefato. Adicione quantos subtópicos precisar. -->
### Versão 1.0

<p align = "justify">
<!-- Desenvolva o documento propriamente neste tópico. Para cada mudança relevante ou impactante, crie um novo subtópico com a versão correspondente (Exemplo: Versão 1.0, Versão 1.1, Versão 1.2) -->
</p>

<p align = "justify">
<!-- Escreva aqui a primeira versão do documento. -->
</p>

## Conclusão  

<p align = "justify">
<!-- Descreva neste tópico como a aplicação da técnica e a criação do documento foi útil para o projeto. -->
</p>

## Referências

<!-- Insira referências relevantes do projeto (com um sinal de '>' antes), se possível priorize por livros e artigos, depois sites, blogs e outros projetos parecidos.
Exemplo:
> Referência
 -->

>

## Autor(es)
<!-- Para cada alteração no documento, lembre-se de descrever as mudanças, a versão, a data e creditar os autores. -->
| Data | Versão | Descrição | Autor(es) |
| -- | -- | -- | -- |
| dd/mm/aa | 1.0 | Criação do documento | Autores | 